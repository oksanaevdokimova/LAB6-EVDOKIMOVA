#ifndef CAMERA_H_INCLUDED
#define CAMERA_H_INCLUDED
void moveCamera(GLfloat &xAngle,GLfloat &zAngle,POINTFLOAT &pos,POINT curPos);
#endif // CAMERA_H_INCLUDED

